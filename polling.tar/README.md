# system_polling berbasis web jquery, ajax, PHP
> ***Menggunakan dataType: "JSON"***  

### masih dengan metode request jquery ajax dan session data PHP
> load data ke database menggunakan PHP PDO(PHP DATA OBJECT) tanpa reload halaman  

> polling dibatasi session berdasarkan ip atau user_agent data type ajax with json

![polling_php1](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json1.png)  
![polling_php2](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json2.png)  
![polling_php3](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json3.png)  
![polling_php4](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json4.png) 
![polling_php5](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json5.png)  
![polling_php6](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json6.png)  
![polling_php7](https://raw.githubusercontent.com/codesyariah122/system_polling/dataType_JSON/system_polling_with_json7.png)

> Layout template menggunakan framework css dari materialize

